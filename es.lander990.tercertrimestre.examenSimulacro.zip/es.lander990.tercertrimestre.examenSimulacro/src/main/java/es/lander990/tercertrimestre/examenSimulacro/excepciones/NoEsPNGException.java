package es.lander990.tercertrimestre.examenSimulacro.excepciones;

public class NoEsPNGException extends Exception{
	
	public NoEsPNGException(String m) {
		super(m);
	}

}
