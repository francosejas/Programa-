package es.lander990.tercertrimestre.examenSimulacro.excepciones;

public class NoEsJPGException extends Exception{
	public NoEsJPGException(String m) {
		super(m);
	}
}
