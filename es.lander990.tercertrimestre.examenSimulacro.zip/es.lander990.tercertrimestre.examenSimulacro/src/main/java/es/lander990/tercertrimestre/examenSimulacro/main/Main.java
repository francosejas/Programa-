package es.lander990.tercertrimestre.examenSimulacro.main;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Scanner;

import es.lander990.tercertrimestre.examenSimulacro.clases.ListadoImagenes;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListadoImagenes li=new ListadoImagenes();
		
		li.soloQuieroImagenesVerdes(new File("./arbol1DAM v1/"));
		li.exportar();

		System.out.println("Dime una fecha (DD/MM/YYYY HH:mm:SS): ");
		Scanner sc=new Scanner(System.in);
		String fechaCompleta=sc.nextLine();
		String[] soloFecha=fechaCompleta.split(" ")[0].split("/");
		String[] soloHora=fechaCompleta.split(" ")[1].split(":");
		
		
		LocalDateTime fecha=LocalDateTime.of(Integer.parseInt(soloFecha[2]), Integer.parseInt(soloFecha[1]), Integer.parseInt(soloFecha[0])
				, Integer.parseInt(soloHora[0]), Integer.parseInt(soloHora[1]), Integer.parseInt(soloHora[2]));
		File archivo=new File("./arbol1DAM v1/Hojas/no es dificil.png");
		archivo.setLastModified(Timestamp.valueOf(fecha).getTime());
		
		sc.close();
	}

}
