package es.lander990.tercertrimestre.examenSimulacro.interfaces;

import java.io.File;

public interface RecorridoYGuardado {
	public void soloQuieroImagenesVerdes(File RutaInicial);
	
	public void exportar();
}
