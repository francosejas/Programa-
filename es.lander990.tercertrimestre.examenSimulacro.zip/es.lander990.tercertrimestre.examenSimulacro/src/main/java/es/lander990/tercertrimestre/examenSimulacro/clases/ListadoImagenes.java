package es.lander990.tercertrimestre.examenSimulacro.clases;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import es.lander990.tercertrimestre.examenSimulacro.excepciones.NoEsJPGException;
import es.lander990.tercertrimestre.examenSimulacro.excepciones.NoEsPNGException;
import es.lander990.tercertrimestre.examenSimulacro.interfaces.RecorridoYGuardado;

public class ListadoImagenes implements RecorridoYGuardado{
	private ArrayList<String> rutasPNG;
	private ArrayList<String> rutasJPG;
	
	public ListadoImagenes() {
		this.rutasJPG = new ArrayList<String>();
		this.rutasPNG = new ArrayList<String>();
	}
	
	public void a�adirPNG(String ruta) throws NoEsPNGException {
		if (! ruta.contains(".png")) {
			throw new NoEsPNGException("Este archivo no es un .png");
		}
		this.rutasPNG.add(ruta);
	}
	
	public void a�adirJPG(String ruta) throws NoEsJPGException {
		if (! ruta.contains(".jpg")) {
			throw new NoEsJPGException("Este archivo no es un .jpg");
		}
		this.rutasJPG.add(ruta);
	}

	@Override
	public void soloQuieroImagenesVerdes(File RutaInicial) {
		File[] hijos = RutaInicial.listFiles();
		if (hijos != null) {
			for (int i=0; i<hijos.length; i++) {
				if (hijos[i].isDirectory()) {
					this.soloQuieroImagenesVerdes(hijos[i]);
				} else {
					if (hijos[i].getName().contains(".jpg") || hijos[i].getName().contains(".png")) {
						try {
							BufferedImage imagen = ImageIO.read(hijos[i]);
							for (int j=0; j<imagen.getWidth(); j++) {
								for (int k=0; k<imagen.getHeight(); k++) {
									imagen.setRGB(j, k, imagen.getRGB(j, k)&Integer.parseInt("00FF00",16));
								}
							}
							if (hijos[i].getName().contains(".jpg")) {
								ImageIO.write(imagen, "JPG", hijos[i]);
								try {
									this.a�adirJPG(hijos[i].getAbsolutePath());
								} catch (NoEsJPGException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							} else {
								ImageIO.write(imagen, "PNG", hijos[i]);
								try {
									this.a�adirPNG(hijos[i].getAbsolutePath());
								} catch (NoEsPNGException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else { //Si no es un jpg o png
						hijos[i].delete();
					}
				}
			}
		}
		
	}

	@Override
	public void exportar() {
		try {
			FileWriter writer = new FileWriter("archivosJPG.txt");
			writer.write(recorreArrayList(this.rutasJPG));
			writer.flush();
			writer.close();
			

			FileWriter writer2 =  new FileWriter("archivosPNG.txt");
			writer2.write(recorreArrayList(this.rutasPNG));
			writer2.flush();
			writer2.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private String recorreArrayList(ArrayList<String> arrayList) {
		String ret="";
		for (int i=0; i<arrayList.size(); i++) {
			ret+=arrayList.get(i) + "\n";
		}
		
		return ret;
	}
}
